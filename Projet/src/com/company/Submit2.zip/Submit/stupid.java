package com.company;

public class stupid {

}
